CSV to JSON converter.



## Introduction

Teaching how to deploy a lib on Pypi at PUC using Poetry and twine







### What this project can do

Read a **csv** file or a **folder** with csv's and convert them to **JSON**
This project is a program running on terminal, preferably install with pipx:





```
pipx install vtr-csv-json-converter
```







To use, just type in:

```
csv_converter --help
```



This will list all available